using Microsoft.EntityFrameworkCore;
using TaskApi.Data;
using TaskApi.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
// OpenAPI (documentación integrada)
builder.Services.AddOpenApi();

// Registrar repositorio en memoria por defecto (se puede sobrescribir con EF si está configurado)
builder.Services.AddSingleton<ITaskRepository, InMemoryTaskRepository>();

// Configuración de persistencia (si UseInMemory=false y hay cadena de conexión se registra EF/MySQL)
var useInMemory = builder.Configuration.GetValue<bool>("UseInMemory", true);
var conn = builder.Configuration.GetConnectionString("Default");
if (!useInMemory && !string.IsNullOrWhiteSpace(conn))
{
    // Sanitizar la cadena de conexión por si viene rodeada de comillas o paréntesis desde variables de entorno
    var cleanConn = conn.Trim();
    if ((cleanConn.StartsWith("\"") && cleanConn.EndsWith("\"")) || (cleanConn.StartsWith("'") && cleanConn.EndsWith("'")))
    {
        cleanConn = cleanConn.Substring(1, cleanConn.Length - 2);
    }
    if (cleanConn.StartsWith("(") && cleanConn.EndsWith(")"))
    {
        cleanConn = cleanConn.Substring(1, cleanConn.Length - 2);
    }

    // Registrar DbContext y repositorio EF (MySQL). La última registración de ITaskRepository prevalecerá.
    builder.Services.AddDbContext<AppDbContext>(options =>
        options.UseMySql(cleanConn, ServerVersion.AutoDetect(cleanConn)));
    builder.Services.AddScoped<ITaskRepository, EfTaskRepository>();
}

var app = builder.Build();


// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{

    app.MapOpenApi();
}

// Servir archivos estáticos (wwwroot) para proporcionar una UI simple
app.UseDefaultFiles();
app.UseStaticFiles();

// Forzar HTTP: no redirigir a HTTPS para evitar errores si HTTPS falla en el entorno
app.UseAuthorization();

app.MapControllers();

// Aplicar migraciones automáticamente si estamos usando MySQL
using (var scope = app.Services.CreateScope())
{
    var logger = scope.ServiceProvider.GetService<Microsoft.Extensions.Logging.ILoggerFactory>()?.CreateLogger("Startup");
    try
    {
        var cfg = scope.ServiceProvider.GetService<Microsoft.Extensions.Configuration.IConfiguration>();
        var useInMemoryCfg = cfg?.GetValue<bool>("UseInMemory", true) ?? true;
        if (!useInMemoryCfg)
        {
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            db.Database.Migrate();
            logger?.LogInformation("Applied migrations successfully.");
        }
    }
    catch (Exception ex)
    {
        // No hacer que la app falle si la migración o la conexión a BD tienen problemas; registrar y continuar con in-memory
        var log = scope.ServiceProvider.GetService<Microsoft.Extensions.Logging.ILogger<Program>>();
        log?.LogError(ex, "Error applying migrations or initializing database. Falling back to in-memory repository.");
    }
}

app.Run();
