# Carga variables desde .env al entorno del proceso (PowerShell)
# Ejecuta: .\load-env.ps1

$envFile = Join-Path $PSScriptRoot ".env"
if (-not (Test-Path $envFile)) {
	Write-Error ".env no encontrado en $PSScriptRoot. Crea .env a partir de .env.example primero."
	exit 1
}

$lines = Get-Content $envFile -ErrorAction Stop
foreach ($line in $lines) {
	$trim = $line.Trim()
	if ([string]::IsNullOrWhiteSpace($trim)) { continue }
	if ($trim.StartsWith('#')) { continue }
	$pair = $trim -split '=',2
	if ($pair.Length -lt 2) { continue }
	$key = $pair[0].Trim()
	$value = $pair[1].Trim()
	[Environment]::SetEnvironmentVariable($key, $value, 'Process')
	Write-Host "Loaded: $key"
}
Write-Host "Env variables loaded into process environment."
