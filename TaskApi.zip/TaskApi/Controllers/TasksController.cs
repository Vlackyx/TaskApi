using Microsoft.AspNetCore.Mvc;
using TaskApi.Models;
using TaskApi.Repositories;

namespace TaskApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly ITaskRepository _repo;

        public TasksController(ITaskRepository repo)
        {
            _repo = repo;
        }

        // GET /api/tasks?search=foo&completed=true
        [HttpGet]
        public ActionResult<IEnumerable<TaskItem>> GetAll([FromQuery] string? search, [FromQuery] bool? completed)
        {
            var items = _repo.GetAll(search, completed);
            return Ok(items);
        }

        // GET /api/tasks/5
        [HttpGet("{id:int}")]
        public ActionResult<TaskItem> Get(int id)
        {
            var item = _repo.Get(id);
            if (item == null) return NotFound();
            return Ok(item);
        }

        // POST /api/tasks
        [HttpPost]
        public ActionResult<TaskItem> Create([FromBody] TaskItem input)
        {
            if (string.IsNullOrWhiteSpace(input.Title)) return BadRequest("Title is required");
            var created = _repo.Add(new TaskItem
            {
                Title = input.Title,
                Description = input.Description,
                IsCompleted = input.IsCompleted
            });
            return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
        }

        // PUT /api/tasks/5
        [HttpPut("{id:int}")]
        public IActionResult Update(int id, [FromBody] TaskItem input)
        {
            var existing = _repo.Get(id);
            if (existing == null) return NotFound();
            existing.Title = input.Title;
            existing.Description = input.Description;
            existing.IsCompleted = input.IsCompleted;
            existing.CompletedAt = input.IsCompleted ? (existing.CompletedAt ?? DateTime.UtcNow) : null;
            var ok = _repo.Update(existing);
            if (!ok) return NotFound();
            return NoContent();
        }

        // DELETE /api/tasks/5
        [HttpDelete("{id:int}")]
        public IActionResult Delete(int id)
        {
            var ok = _repo.Delete(id);
            if (!ok) return NotFound();
            return NoContent();
        }

        // PATCH /api/tasks/5/complete
        [HttpPatch("{id:int}/complete")]
        public IActionResult MarkComplete(int id)
        {
            var ok = _repo.MarkCompleted(id);
            if (!ok) return NotFound();
            return NoContent();
        }
    }
}
