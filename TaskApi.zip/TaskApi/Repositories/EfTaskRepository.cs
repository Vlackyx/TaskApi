using System;
using System.Collections.Generic;
using System.Linq;
using TaskApi.Models;
using TaskApi.Data;

namespace TaskApi.Repositories
{
    public class EfTaskRepository : ITaskRepository
    {
        private readonly AppDbContext _db;
        public EfTaskRepository(AppDbContext db)
        {
            _db = db;
        }

        public TaskItem Add(TaskItem item)
        {
            item.CreatedAt = DateTime.UtcNow;
            _db.Tasks.Add(item);
            _db.SaveChanges();
            return item;
        }

        public bool Delete(int id)
        {
            var e = _db.Tasks.Find(id);
            if (e == null) return false;
            _db.Tasks.Remove(e);
            _db.SaveChanges();
            return true;
        }

        public TaskItem? Get(int id)
        {
            return _db.Tasks.Find(id);
        }

        public IEnumerable<TaskItem> GetAll(string? search = null, bool? completed = null)
        {
            var q = _db.Tasks.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search))
            {
                var s = search.Trim();
                q = q.Where(t => t.Title.Contains(s));
            }
            if (completed.HasValue)
            {
                q = q.Where(t => t.IsCompleted == completed.Value);
            }
            return q.OrderBy(t => t.Id).ToList();
        }

        public bool MarkCompleted(int id)
        {
            var e = _db.Tasks.Find(id);
            if (e == null) return false;
            if (!e.IsCompleted)
            {
                e.IsCompleted = true;
                e.CompletedAt = DateTime.UtcNow;
                _db.SaveChanges();
            }
            return true;
        }

        public bool Update(TaskItem item)
        {
            var existing = _db.Tasks.Find(item.Id);
            if (existing == null) return false;
            existing.Title = item.Title;
            existing.Description = item.Description;
            existing.IsCompleted = item.IsCompleted;
            existing.CompletedAt = item.IsCompleted ? (existing.CompletedAt ?? DateTime.UtcNow) : null;
            _db.SaveChanges();
            return true;
        }
    }
}
