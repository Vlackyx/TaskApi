using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using TaskApi.Models;

namespace TaskApi.Repositories
{
    public class InMemoryTaskRepository : ITaskRepository
    {
        private readonly ConcurrentDictionary<int, TaskItem> _items = new();
        private int _nextId = 0;

        public InMemoryTaskRepository()
        {
            // Datos iniciales de ejemplo
            Add(new TaskItem { Title = "Comprar leche", Description = "Ir al supermercado", CreatedAt = DateTime.UtcNow, IsCompleted = false });
            Add(new TaskItem { Title = "Enviar informe", Description = "Enviar por email antes del viernes", CreatedAt = DateTime.UtcNow, IsCompleted = false });
        }

        public TaskItem Add(TaskItem item)
        {
            var id = Interlocked.Increment(ref _nextId);
            item.Id = id;
            item.CreatedAt = DateTime.UtcNow;
            _items[id] = item;
            return item;
        }

        public bool Delete(int id)
        {
            return _items.TryRemove(id, out _);
        }

        public TaskItem? Get(int id)
        {
            _items.TryGetValue(id, out var item);
            return item;
        }

        public IEnumerable<TaskItem> GetAll(string? search = null, bool? completed = null)
        {
            var query = _items.Values.AsEnumerable();
            if (!string.IsNullOrWhiteSpace(search))
            {
                var s = search.Trim();
                query = query.Where(t => t.Title.Contains(s, StringComparison.OrdinalIgnoreCase));
            }
            if (completed.HasValue)
            {
                query = query.Where(t => t.IsCompleted == completed.Value);
            }
            return query.OrderBy(t => t.Id);
        }

        public bool MarkCompleted(int id)
        {
            if (_items.TryGetValue(id, out var item))
            {
                if (!item.IsCompleted)
                {
                    item.IsCompleted = true;
                    item.CompletedAt = DateTime.UtcNow;
                    _items[id] = item;
                }
                return true;
            }
            return false;
        }

        public bool Update(TaskItem item)
        {
            if (!_items.ContainsKey(item.Id)) return false;
            var existing = _items[item.Id];
            existing.Title = item.Title;
            existing.Description = item.Description;
            // No sobrescribir estado de completado a menos que venga explícito
            existing.IsCompleted = item.IsCompleted;
            existing.CompletedAt = item.IsCompleted ? (existing.CompletedAt ?? DateTime.UtcNow) : null;
            _items[item.Id] = existing;
            return true;
        }
    }
}
