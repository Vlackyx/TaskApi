using System.Collections.Generic;
using TaskApi.Models;

namespace TaskApi.Repositories
{
    public interface ITaskRepository
    {
        IEnumerable<TaskItem> GetAll(string? search = null, bool? completed = null);
        TaskItem? Get(int id);
        TaskItem Add(TaskItem item);
        bool Update(TaskItem item);
        bool Delete(int id);
        bool MarkCompleted(int id);
    }
}
