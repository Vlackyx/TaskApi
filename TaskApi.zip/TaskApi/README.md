# TaskApi

API REST simple de tareas creada con ASP.NET Core (.NET 10).

Descripción
- API para crear, leer, actualizar, eliminar y marcar tareas como completadas.
- Incluye un repositorio en memoria (InMemoryTaskRepository) y una UI estática mínima en `wwwroot/index.html` que consume la API.

Características
- Endpoints:
  - GET    /api/tasks
  - GET    /api/tasks/{id}
  - POST   /api/tasks
  - PUT    /api/tasks/{id}
  - DELETE /api/tasks/{id}
  - PATCH  /api/tasks/{id}/complete
- OpenAPI (especificación JSON) en `/openapi`
- UI simple en `/` (sirve la página estática que consume la API)

Tecnologías
- .NET 10 / ASP.NET Core
- C#
- Repositorio en memoria (ConcurrentDictionary)
- UI estática (HTML + JS) en `wwwroot`

Requisitos
- .NET 10 SDK instalado: https://dotnet.microsoft.com

Variables de entorno
- Crea un fichero `.env` a partir de `TaskApi/.env.example` y rellena tus valores (no subir `.env` al repositorio).
- Variables soportadas:
  - ConnectionStrings__Default: cadena de conexión MySQL completa
  - UseInMemory: true|false

Ejecutar localmente
1. Usando repositorio en memoria (por defecto):
   ```powershell
   cd C:\Users\<tu-usuario>\source\repos\TaskApi\TaskApi
   dotnet run
   ```

2. Usando MySQL local o remoto:
   - Crea `.env` con ConnectionStrings__Default y `UseInMemory=false` o configura `appsettings.Development.json` localmente.
   - (Opcional) Instala dotnet-ef para gestionar migraciones:
	 ```powershell
	 dotnet tool install --global dotnet-ef
	 dotnet ef migrations add InitialCreate
	 dotnet ef database update
	 ```
   - Ejecuta la app:
	 ```powershell
	 cd TaskApi
	 dotnet run
	 ```

3. Usando Docker (MySQL + app):
   ```bash
   docker compose up --build
   ```

Abrir en el navegador:
  - UI: http://localhost:5005/
  - API: http://localhost:5005/api/tasks
  - OpenAPI (JSON): http://localhost:5005/openapi

Ejemplos rápidos (curl)
- Listar tareas:
  ```bash
  curl http://localhost:5005/api/tasks
  ```
- Crear tarea:
  ```bash
  curl -X POST http://localhost:5005/api/tasks -H "Content-Type: application/json" -d '{"title":"Comprar","description":"Leche"}'
  ```

Sugerencias para publicar en GitHub
- Añadir `.gitignore` (ya incluido) y `LICENSE` (por ejemplo MIT).
- Escribir un `README.md` completo (esta es una versión básica).
- Añadir pruebas unitarias y CI (GitHub Actions) para mostrar buenas prácticas.
- Considerar migrar a EF Core + SQLite para persistencia real.

Próximos pasos recomendados
- Validación de entrada y DTOs.
- Persistencia con EF Core y migraciones.
- Tests (xUnit) y GitHub Actions.
- Dockerfile para despliegue.

Licencia
- Añade un archivo LICENSE (p. ej. MIT) antes de publicar en público.
